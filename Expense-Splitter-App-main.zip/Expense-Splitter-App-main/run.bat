@echo off
echo Launching project via native Maven Wrapper...

cd /d "%~dp0"

if exist "mvnw.cmd" (
    echo Wrapper found. Automatically resolving dependencies and running...
    call mvnw.cmd compile exec:java
) else (
    echo ============================================================
    echo ERROR: mvnw.cmd not found in the project root folder.
    echo Make sure you generated the wrapper files inside the IDE first.
    echo ============================================================
)

pause