import db.DatabaseManager;
import db.ExpenseDAO;
import gui.LoginScreen;
import gui.MainWindow;

public class Main {
    public static void main(String[] args) {
        DatabaseManager db = new DatabaseManager();
        db.connect();
        db.createTable();
        ExpenseDAO dao = new ExpenseDAO(db);

        new LoginScreen(dao);
        //MainWindow mainWindow = new MainWindow(dao);
        //mainWindow.show();
    }
}
    