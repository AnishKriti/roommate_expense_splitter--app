package gui;

import core.Expense;
import core.Group;
import core.OneTimeExpense;
import core.User;
import db.ExpenseDAO;
import engine.DebtSimplifier;
import engine.Transaction;
import report.ReportExporter;
import split.EqualSplit;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainWindow{
    private final JFrame frame;
    private final ExpenseDAO dao;
    private final JPanel contentPanel;
    private final User currentUser;
    public MainWindow(ExpenseDAO dao, User currentUser){
        this.dao = dao;
        this.currentUser = currentUser;
        frame = new JFrame("Expense Splitter");
        frame.setSize(1000, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("Expense Manager - "+currentUser.getName(), JLabel.CENTER);
        frame.add(title, BorderLayout.NORTH);
        JPanel buttonPanel = new JPanel(new GridLayout(5, 1, 10, 10));

        //Add button
        JButton addBtn = new JButton("Add Expense");
        addBtn.addActionListener(e -> addExpenseDialogBox());

        //View Button
        JButton viewBtn = new JButton("View Expenses");
        viewBtn.addActionListener(e -> viewExpenses());

        //Group Button
        JButton viewGrpBtn = new JButton("Groups");
        viewGrpBtn.addActionListener(e -> groupView());

        //Home Screen Button
        JButton homeBtn = new JButton("Home");
        homeBtn.addActionListener(e -> homeScreen());

        //Monthly Report Button
        JButton monthlyReportBtn = new JButton("Monthly Report");
        monthlyReportBtn.addActionListener(e -> dateView());

        contentPanel = new JPanel();
        homeScreen();

        buttonPanel.add(homeBtn);
        buttonPanel.add(addBtn);
        buttonPanel.add(viewBtn);
        buttonPanel.add(viewGrpBtn);
        buttonPanel.add(monthlyReportBtn);

        frame.add(buttonPanel, BorderLayout.WEST);
        frame.add(contentPanel, BorderLayout.CENTER);
    }

    private void homeScreen(){
        JLabel welcomeMsgLabel = new JLabel("Welcome Back, "+currentUser.getName());
        welcomeMsgLabel.setFont(new Font("MV Boli", Font.BOLD, 40));
        welcomeMsgLabel.setBounds(250, 80, 440, 120);

        double totalSpentAmount = dao.getSumAmount(currentUser.getId(), "Debit");
        double totalCreditAmount = dao.getSumAmount(currentUser.getId(), "Credit");

        JLabel totalUserCreditedLabel = new JLabel("Total Credited: "+ totalCreditAmount+" \u20B9");
        totalUserCreditedLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));

        JLabel totalUserSpendingLabel = new JLabel("Total Money Spent: "+totalSpentAmount+" \u20B9");
        totalUserSpendingLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));

        JPanel amountPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        amountPanel.setBounds( 50, 180, 800, 120);
        amountPanel.add(totalUserCreditedLabel);
        amountPanel.add(totalUserSpendingLabel);

        contentPanel.removeAll();
        contentPanel.setLayout(null);
        contentPanel.add(welcomeMsgLabel);
        contentPanel.add(amountPanel);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    public void show(){
        frame.setVisible(true);
    }

    // User
    public void addExpenseDialogBox(){
        JDialog dialog = new JDialog(frame, "Add Expense", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(null);

        // Elements
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));
        JTextField descField = new JTextField();
        String[] transactions = {"Credit", "Debit"};
        JComboBox<String> transactionBox = new JComboBox<>(transactions);
        transactionBox.setSelectedIndex(-1);

        JTextField amountField = new JTextField();
        JButton confirmBtn = new JButton("Add");

        descField.addActionListener(e -> amountField.requestFocus()); // Uses enter to switch to next field
        amountField.addActionListener(e -> confirmBtn.doClick());

        //Adding elements
        panel.add(new JLabel("Description: "));
        panel.add(descField);
        panel.add(new JLabel("Amount: "));
        panel.add(amountField);
        panel.add(new JLabel("Transaction: "));
        panel.add(transactionBox);
        panel.add(new JLabel(""));
        panel.add(confirmBtn);

        confirmBtn.addActionListener(ev -> {
            try{
                String desc = descField.getText();
                String transaction = transactionBox.getSelectedItem().toString();

                double amount = Double.parseDouble(amountField.getText());

                if (amount <= 0) {
                    JOptionPane.showMessageDialog(dialog, "Amount cannot be less than 0", "Invalid Amount", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                LocalDateTime currentDateTime = LocalDateTime.now();
                OneTimeExpense expense = new OneTimeExpense(1, desc, amount, currentUser, currentDateTime, transaction);
                dao.saveExpense(expense);
                JOptionPane.showMessageDialog(dialog, "Expense Added", "Success", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            }
            catch(NullPointerException e){
                JOptionPane.showMessageDialog(dialog, "Transaction cannot be empty", "Empty Transaction", JOptionPane.WARNING_MESSAGE);
            }
            catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Please enter a valid amount!");
                }
            });
        dialog.add(panel);
        dialog.setVisible(true);
    }
    public void viewExpenses() {
        List<Expense> expenses = dao.getUserExpense(currentUser.getId());

        UserExpenseModel userExpenseTableModel = new UserExpenseModel(expenses);
        JTable userExpenseTable = new JTable(userExpenseTableModel);
        userExpenseTable.getTableHeader().setResizingAllowed(false);
        userExpenseTable.getTableHeader().setReorderingAllowed(false);

        JPanel tablePanel = new JPanel();
        tablePanel.add(new JScrollPane(userExpenseTable));

        JPanel btnPanel = new JPanel(new GridBagLayout());
        JButton dltUserExpense = new JButton("Delete Expense");
        dltUserExpense.addActionListener(e -> {
            int selectedMember = userExpenseTable.getSelectedRow();
            if(selectedMember == -1){
                JOptionPane.showMessageDialog(frame, "Select a Member");
            }
            else{
                dao.deleteExpense(expenses.get(selectedMember).getId());
                expenses.remove(selectedMember);
                userExpenseTableModel.fireTableRowsDeleted(selectedMember, selectedMember);
            }
        });
        btnPanel.add(dltUserExpense);

        JPanel totalSpendingPanel = new JPanel();

        double totalAmountSpent = dao.getSumAmount(currentUser.getId(), "Debit");
        double totalAmountCredited = dao.getSumAmount(currentUser.getId(), "Credit");
        double totalAmount = totalAmountCredited - totalAmountSpent;

        JLabel totalSpendingLabel = new JLabel("Net Balance: "+ totalAmount);
        totalSpendingLabel.setFont(new Font("MV Boli", Font.BOLD, 30));
        totalSpendingPanel.add(totalSpendingLabel);

        contentPanel.removeAll();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.add(tablePanel, BorderLayout.CENTER);
        contentPanel.add(btnPanel, BorderLayout.EAST);
        contentPanel.add(totalSpendingPanel, BorderLayout.SOUTH);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    //Group
    public void groupView(){
        Map<Integer, String> groups = dao.getAllGroups();

        GroupTable tableModel = new GroupTable(groups);
        JTable groupTable = new JTable(tableModel);
        groupTable.getTableHeader().setResizingAllowed(false);
        groupTable.getTableHeader().setReorderingAllowed(false);

        contentPanel.removeAll();
        if(!groups.isEmpty()){
            contentPanel.setLayout(new FlowLayout());
            contentPanel.add(new JScrollPane(groupTable));
            JPanel btnPanel = new JPanel();
            btnPanel.setLayout(new GridLayout(3, 1, 10, 10));

            // Add group button
            JButton addGroup = new JButton("Add Group");
            addGroup.addActionListener(e -> addGroup());

            // View Group button
            JButton viewBtn = new JButton("View Group");
            viewBtn.addActionListener(e -> {
                int selectedRow = groupTable.getSelectedRow();
                if(selectedRow == -1){
                    JOptionPane.showMessageDialog(frame, "Select a group", "No Group Selected", JOptionPane.WARNING_MESSAGE);
                }
                else{
                    int groupID = tableModel.getGroupId(selectedRow);
                    String groupName = groupTable.getValueAt(selectedRow, 1).toString();
                    viewGroupDetails(groupID, groupName);
                }
            });

            //Delete Group button
            JButton dltBtn = new JButton("Delete Group");
            dltBtn.addActionListener(e -> {
                try{
                    int selectedRow = groupTable.getSelectedRow();
                    int groupId = tableModel.getGroupId(selectedRow);
                    dao.deleteGroup(groupId);
                    tableModel.removeRow(selectedRow);
                    tableModel.fireTableRowsDeleted(selectedRow, selectedRow);
                }
                catch(IndexOutOfBoundsException err){
                    JOptionPane.showMessageDialog(frame, "Select a Group", "No Group Selected", JOptionPane.WARNING_MESSAGE);
                }


            });

            btnPanel.add(addGroup);
            btnPanel.add(viewBtn);
            btnPanel.add(dltBtn);

            contentPanel.add(btnPanel);
        }
        else{
            contentPanel.setLayout(null);
            JLabel noGroupsLabel = new JLabel("No groups created", JLabel.CENTER);
            noGroupsLabel.setBounds(150, 150, 500, 70);
            noGroupsLabel.setFont(new Font("MV Boli", Font.BOLD, 45));
            JButton addGroup = new JButton("Add Group");
            addGroup.setBounds(350, 300, 100, 50);
            addGroup.addActionListener(e -> addGroup());
            contentPanel.add(noGroupsLabel);
            contentPanel.add(addGroup);
        }
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    public void addGroup() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        JTextField grpNameField = new JTextField();
        JTextField noOfMembersField = new JTextField();

        panel.add(new Label("Group Name: "));
        panel.add(grpNameField);

        int result = JOptionPane.showOptionDialog(null, panel, "Group Details", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, null, 0);
        String groupName;
        if (result == JOptionPane.OK_OPTION) {
            try{
                groupName = grpNameField.getText().trim();
                if(groupName.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Type Group Name", "Group Name not added", JOptionPane.WARNING_MESSAGE);
                }
                else {
                    Group group = new Group(groupName);
                    int groupID = dao.saveGroup(group);
                    addDetails(groupID, groupName);
                }
            }
            catch(NullPointerException e){
                JOptionPane.showMessageDialog(null, "Fields cannot be empty!");
            }
            catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Member field can only have numbers!");
            }

        }
    }
    //Group members
    public void addDetails(int groupID, String groupName){
        JDialog details = new JDialog();
        details.setSize(300, 200);
        details.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2));
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JButton confirmBtn = new JButton("Add");

        nameField.addActionListener(e -> emailField.requestFocus());
        emailField.addActionListener(e -> confirmBtn.doClick());

        panel.add(new JLabel("Name: "));
        panel.add(nameField);
        panel.add(new JLabel("Email: "));
        panel.add(emailField);
        panel.add(new JLabel(""));
        panel.add(confirmBtn);

        confirmBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            if(name.isEmpty()){
                JOptionPane.showMessageDialog(details, "Please enter Name!");
                return;
            }
            String email = emailField.getText().trim();
            User user = new User(0, name, email);

            dao.saveGroupMembers(groupID, user);
            details.dispose();
            viewGroupDetails(groupID, groupName);
        });
        details.add(panel);
        details.setVisible(true);
    }
    public void viewGroupDetails(int groupID, String groupName){
        try{
            List<User> members = dao.getAllMembers(groupID);
            final double[] total = {totalSpending(members)};
//            String[] columns = {
//                    "Group ID","Name", "Email", "Total Paid", "Balance", "Amount Per Person"};
//            Object[][] data = new Object[members.size()][6];
//
//            for(int i=0; i<members.size(); i++){
//                data[i][0] = groupID;
//                data[i][1] = members.get(i).getName();
//                data[i][2] = members.get(i).getEmail();
//                data[i][3] = members.get(i).getTotalPaid();
//                data[i][4] = members.get(i).getTotalPaid() - members.get(i).getTotalOwed();
//                data[i][5] = members.get(i).getTotalOwed();
//            }

//            JTable membersTable = new JTable(data, columns);

            //Table
            MemberTableModel tableModel = new MemberTableModel(members);
            JTable membersTable = new JTable(tableModel);
            TableCells.autoResizeColumns(membersTable);

            //Panels
            JPanel totalingPanel = new JPanel(); //shows total members and total spending

            JPanel groupPanel = new JPanel();  // shows group no.

            JPanel btnPanel = new JPanel(); // for buttons
            btnPanel.setLayout(new GridLayout(7, 1, 10, 10));

            JPanel tablePanel = new JPanel(); // for table
            tablePanel.add(new JScrollPane(membersTable));

            //Labels
            JLabel groupLabel = new JLabel("Group: "+groupName); // prints group no.
            groupLabel.setFont(new Font("MV Boli", Font.BOLD, 18));

            JLabel totalAmount = new JLabel("Total Spending: "+ total[0]); // prints total spending
            totalAmount.setFont(new Font("MV Boli", Font.BOLD, 30));

            JLabel totalMembers = new JLabel("Total Members: "+members.size()); // prints total members
            totalMembers.setFont(new Font("MV Boli", Font.BOLD, 30));

            //Buttons
            JButton addMemberBtn = new JButton("Add Members");
            addMemberBtn.addActionListener(e -> addDetails(groupID, groupName));

            JButton deleteMemberBtn = new JButton("Delete Member");
            deleteMemberBtn.addActionListener(e -> {
                int selectedMember = membersTable.getSelectedRow();
                if(selectedMember == -1){
                    JOptionPane.showMessageDialog(frame, "Select a Member");
                }
                else{
                    dao.deleteGroupMembers(members.get(selectedMember).getId());
                    members.remove(selectedMember);
                    tableModel.fireTableRowsDeleted(selectedMember, selectedMember);
                }
            });

            JButton viewExpensesBtn = new JButton("View Expenses");
            viewExpensesBtn.addActionListener(e -> viewGroupExpenses(groupID));

            JButton simplifyDebtBtn = new JButton("Simplify Debts");
            simplifyDebtBtn.addActionListener(e -> simplify(members));

            JButton addPaymentBtn = new JButton("Add Payment");
            addPaymentBtn.addActionListener(e -> {
                int selectedMember = membersTable.getSelectedRow();
                if(selectedMember == -1){
                    JOptionPane.showMessageDialog(frame, "Select a Member");
                }
                else{
                    addAmount(members, members.get(selectedMember), groupID);
                    tableModel.fireTableRowsUpdated(selectedMember, selectedMember);
                }
            });

            JButton refreshBtn = new JButton("Refresh");
            refreshBtn.addActionListener(e -> {
                List<User> freshData = refresh(groupID);
                members.clear();
                members.addAll(freshData);
                tableModel.fireTableDataChanged();
                total[0] = totalSpending(members);
                totalAmount.setText("Total Spending: "+ total[0]);
                totalMembers.setText("Total Members: "+members.size());

            });


            groupPanel.setSize(100, 100);
            groupPanel.add(groupLabel);

            btnPanel.add(groupPanel);
            btnPanel.add(refreshBtn);
            btnPanel.add(addMemberBtn);
            btnPanel.add(deleteMemberBtn);
            btnPanel.add(addPaymentBtn);
            btnPanel.add(viewExpensesBtn);
            btnPanel.add(simplifyDebtBtn);

            totalingPanel.add(totalAmount);
            totalingPanel.add(totalMembers);


            contentPanel.removeAll();
//            contentPanel.setLayout(new FlowLayout());
            contentPanel.setLayout(new BorderLayout());
            contentPanel.add(tablePanel, BorderLayout.CENTER);
            contentPanel.add(btnPanel, BorderLayout.EAST);
            contentPanel.add(totalingPanel,  BorderLayout.SOUTH);
            contentPanel.revalidate();
            contentPanel.repaint();
        }
        catch(NullPointerException e){
            JOptionPane.showMessageDialog(frame, "No groups created!", "Error",JOptionPane.ERROR_MESSAGE);
        }
    }

    //Group expenses
    public void viewGroupExpenses(int groupID){
        JDialog dialog = new JDialog(frame, "Expenses");
        dialog.setLayout(new BorderLayout());

        List<Expense> expenses = dao.getMemberExpense(groupID);

        MemberExpenseTable tableModel = new MemberExpenseTable(expenses);
        JTable memberExpenseTable = new JTable(tableModel);
        memberExpenseTable.getTableHeader().setResizingAllowed(false);
        memberExpenseTable.getTableHeader().setReorderingAllowed(false);

        JPanel panel = new JPanel();
        JScrollPane tablePane = new JScrollPane(memberExpenseTable);
        tablePane.setSize(470, 200);
        JPanel btnPanel = new JPanel();

        JButton deleteExpenseBtn = new JButton("Delete Expense");
        deleteExpenseBtn.addActionListener(e -> {
            try{
                int selectedExpense = memberExpenseTable.getSelectedRow();
                dao.deleteMemberExpense(expenses.get(selectedExpense).getId());
                expenses.remove(selectedExpense);
                tableModel.fireTableRowsDeleted(selectedExpense, selectedExpense);
            }
            catch(IndexOutOfBoundsException err){
                JOptionPane.showMessageDialog(dialog, "Select an Expense", "No Expense Selected", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnPanel.add(deleteExpenseBtn);
        panel.add(tablePane, BorderLayout.NORTH);
        panel.add(btnPanel, BorderLayout.SOUTH);
        dialog.add(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }
    public void addAmount(List<User> members, User u, int groupID){
        JDialog dialog = new JDialog(frame, "Add Expense", true);
        dialog.setSize(300, 200);
        dialog.setLocationRelativeTo(null);

        // Elements
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        JTextField descField = new JTextField();
        JTextField amountField = new JTextField();
        JButton confirmBtn = new JButton("Add");

        descField.addActionListener(e -> amountField.requestFocus()); // Uses enter to switch to next field
        amountField.addActionListener(e -> confirmBtn.doClick());

        //Adding elements
        panel.add(new JLabel("Description: "));
        panel.add(descField);
        panel.add(new JLabel("Amount: "));
        panel.add(amountField);
        panel.add(new JLabel(""));
        panel.add(confirmBtn);

        confirmBtn.addActionListener(ev -> {
            String desc = descField.getText(); //desc
            double amount;
            try {amount = Double.parseDouble(amountField.getText());} //amount
            catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Please enter a valid amount!");
                return;
            }
            if(amount <= 0){
                JOptionPane.showMessageDialog(dialog, "Amount cannot be less than 0", "Invalid Amount", JOptionPane.WARNING_MESSAGE);
                return;
            }
            u.addPayment(amount);
            EqualSplit split = new EqualSplit();
            LocalDateTime currentDateTime = LocalDateTime.now();
            OneTimeExpense expense = new OneTimeExpense(0, desc, amount, u, currentDateTime, "Debit");
            double amountPerPerson = split.split(amount, members);

            for(User i : members){
                if(i.getId()==u.getId()){
                    //saving for selected member
                    u.addDebt(amountPerPerson);
                    dao.saveMemberAmount(u);
                    dao.saveMemberExpense(expense, groupID);
                }
                else{
                    //updating debts for others
                    i.addDebt(amountPerPerson);
                    dao.saveMemberAmount(i);
                }
            }
            JOptionPane.showMessageDialog(dialog, "Expense Added", "Success", JOptionPane.INFORMATION_MESSAGE);
            dialog.dispose();
        });
        dialog.add(panel);
        dialog.setVisible(true);
    }
    public void simplify(List<User> members){
        JDialog simplifyDebtDialog = new JDialog(frame,"Simplified Transaction");
        simplifyDebtDialog.setSize(400, 300);
        simplifyDebtDialog.setLocationRelativeTo(null);

        Map<User, Double> balances = new HashMap<>();
        DebtSimplifier debtSimplifier = new DebtSimplifier();

        for(User user : members){
            balances.put(user, user.getTotalPaid() - user.getTotalOwed());
        }

        List<Transaction> transactions = debtSimplifier.simplify(balances);

        DebtSimplifierTable tableModel = new DebtSimplifierTable(transactions);
        JTable transactionTable = new JTable(tableModel);
        TableCells.autoResizeColumns(transactionTable);


        simplifyDebtDialog.add(new JScrollPane(transactionTable));
        simplifyDebtDialog.setVisible(true);
    }
    private List<User> refresh(int groupID){
        List<User> members = dao.getAllMembers(groupID);
        List<Expense> expenses = dao.getMemberExpense(groupID);

        for(User member: members){
            member.setTotalOwed(0);
            member.setTotalPaid(0);
        }

        EqualSplit split = new EqualSplit();
        for(Expense expense : expenses){
            double amountPerPerson = split.split(expense.getAmount(), members);
            User paidByUser = null;

            for(User member : members){
                if(member.getId() == expense.getPaidBy().getId()){
                    paidByUser = member;
                    break;
                }
            }

            if(paidByUser != null){
                paidByUser.addPayment(expense.getAmount());
            }

            for(User member : members){
                member.addDebt(amountPerPerson);
            }
        }

        for(User member : members){
            dao.saveMemberAmount(member);
        }
        return members;
    }
    private double totalSpending(List<User> members){
        double total = 0;
        for(User user : members){
            total += user.getTotalPaid();
        }
        return total;
    }

    //Monthly Report
    public void dateView(){
        JDialog monthlyReportDialogBox = new JDialog(frame, "Monthly Report");
        monthlyReportDialogBox.setSize(400, 300);
        monthlyReportDialogBox.setLocationRelativeTo(null);
        monthlyReportDialogBox.setLayout(new GridLayout(4, 1, 30, 30));

        String[] months = {"January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"};
        Integer[] days = new Integer[31];
        Integer[] years = new Integer[26];
        for(int i=0; i<31; i++){
            days[i] = i+1;
        }
        for(int i=0; i<26; i++){
            years[i] = 2000+i+1;
        }

        JComboBox<Integer> dayPicker = new JComboBox<>(days);
        JComboBox<String> monthPicker = new JComboBox<>(months);
        JComboBox<Integer> yearPicker = new JComboBox<>(years);

        JButton submitDateBtn = new JButton("Submit");
        submitDateBtn.addActionListener(e -> {
            try{
                int selectedDay = (Integer) dayPicker.getSelectedItem();
                int selectedMonth = monthPicker.getSelectedIndex() + 1;
                int selectedYear = (Integer) yearPicker.getSelectedItem();

                LocalDate startDate = LocalDate.of(selectedYear, selectedMonth, selectedDay);
                LocalDate endDate = startDate.with(TemporalAdjusters.lastDayOfMonth());

                List<Expense> monthlyExpense = dao.getMonthlyExpense(currentUser.getId(), startDate, endDate);

                monthlyReport(currentUser, monthlyExpense, startDate, endDate);
                monthlyReportDialogBox.dispose();
            }catch(NullPointerException err){
                JOptionPane.showMessageDialog(null, "Select a Date", "Date not selected", JOptionPane.WARNING_MESSAGE);
            }
        });
        monthlyReportDialogBox.add(dayPicker);
        monthlyReportDialogBox.add(monthPicker);
        monthlyReportDialogBox.add(yearPicker);
        monthlyReportDialogBox.add(submitDateBtn);
        monthlyReportDialogBox.setVisible(true);
    }
    public void monthlyReport(User currentUser, List<Expense> expenses, LocalDate startDate, LocalDate endDate){

        UserExpenseModel userExpenseTableModel = new UserExpenseModel(expenses);
        JTable monthlyExpenseTable = new JTable(userExpenseTableModel);
        monthlyExpenseTable.getTableHeader().setResizingAllowed(false);
        monthlyExpenseTable.getTableHeader().setReorderingAllowed(false);

        JPanel tablePanel = new JPanel();
        tablePanel.add(new JScrollPane(monthlyExpenseTable));

        JPanel btnPanel = new JPanel(new GridBagLayout());

        JButton exportBtn = new JButton("Export Report");
        exportBtn.addActionListener(e -> {
            ReportExporter exporter = new ReportExporter();
            exporter.export(monthlyExpenseTable, currentUser);
        });
        btnPanel.add(exportBtn);

        JPanel totalSpendingPanel = new JPanel();

        double totalAmountSpent = dao.getSumAmount(currentUser.getId(), "Debit", startDate, endDate);
        double totalAmountCredited = dao.getSumAmount(currentUser.getId(), "Credit", startDate, endDate);
        double totalAmount = totalAmountCredited - totalAmountSpent;

        JLabel totalSpentLabel = new JLabel("Total Spent: "+ totalAmountSpent);
        totalSpentLabel.setFont(new Font("MV Boli", Font.BOLD, 30));
        totalSpendingPanel.add(totalSpentLabel);

        JLabel totalReceivedLabel = new JLabel("Total Received: "+ totalAmountCredited);
        totalReceivedLabel.setFont(new Font("MV Boli", Font.BOLD, 30));
        totalSpendingPanel.add(totalReceivedLabel);

        JLabel totalSpendingLabel = new JLabel("Net Balance: "+ totalAmount);
        totalSpendingLabel.setFont(new Font("MV Boli", Font.BOLD, 30));
        totalSpendingPanel.add(totalSpendingLabel);

        contentPanel.removeAll();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.add(tablePanel, BorderLayout.CENTER);
        contentPanel.add(btnPanel, BorderLayout.EAST);
        contentPanel.add(totalSpendingPanel, BorderLayout.SOUTH);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
}