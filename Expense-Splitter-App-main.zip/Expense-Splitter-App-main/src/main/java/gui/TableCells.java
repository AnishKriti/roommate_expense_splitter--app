package gui;

import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class TableCells {
    public static void autoResizeColumns(JTable table){
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getTableHeader().setResizingAllowed(false);
        table.getTableHeader().setReorderingAllowed(false);

        final TableColumnModel columnModel = table.getColumnModel();
        for(int i=0; i<table.getColumnCount(); i++){
            TableColumn tableColumn = columnModel.getColumn(i);
            String columnName = table.getColumnName(i);
            switch (columnName){
                case "Email" -> tableColumn.setPreferredWidth(180);
                case "Group ID" -> tableColumn.setPreferredWidth(30);
                case "Total Paid", "Balance", "Split" -> tableColumn.setPreferredWidth(60);
                case "From", "To", "Amount" -> tableColumn.setPreferredWidth(127);
                default -> tableColumn.setPreferredWidth(90);
            }
        }
    }
}
