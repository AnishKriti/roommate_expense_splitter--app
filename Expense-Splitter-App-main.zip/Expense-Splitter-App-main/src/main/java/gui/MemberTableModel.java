package gui;
import core.User;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class MemberTableModel extends AbstractTableModel{
    private String[] columns = {
            "Name", "Email", "Total Paid", "Balance", "Split"};
    private List<User> members;
    MemberTableModel(List<User> members){
        this.members = members;
    }
    @Override
    public int getRowCount() {
        return members.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int column){
        return columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        User user = members.get(rowIndex);
        return switch (columnIndex){
            case 0 -> user.getName();
            case 1 -> user.getEmail();
            case 2 -> user.getTotalPaid();
            case 3 -> String.format("%.2f",user.getTotalPaid() - user.getTotalOwed());
            case 4 -> String.format("%.2f",user.getTotalOwed());
            default -> null;
        };
    }
}
