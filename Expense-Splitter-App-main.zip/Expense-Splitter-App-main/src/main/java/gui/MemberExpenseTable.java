package gui;

import core.Expense;

import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class MemberExpenseTable extends AbstractTableModel {
    private List<Expense> expenses;
    String[] columns = {"Description", "Amount", "Paid By", "Date & Time"};

    MemberExpenseTable(List<Expense> expenses){
        this.expenses = expenses;
    }

    @Override
    public int getRowCount(){
        return expenses.size();
    }

    @Override
    public int getColumnCount(){
        return columns.length;
    }

    @Override
    public String getColumnName(int column){
        return columns[column];
    }

    private String getDateTime(int rowIndex){
        DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String formattedDateTime = "";
        if(expenses.get(rowIndex).getDateTime()!=null){
            formattedDateTime = dateTimeFormat.format(expenses.get(rowIndex).getDateTime());
        }
        return formattedDateTime;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        Expense expense = expenses.get(rowIndex);
        String formattedDateTime = getDateTime(rowIndex);
        return switch (columnIndex){
            case 0 -> expense.getDescription();
            case 1 -> expense.getAmount();
            case 2 -> expense.getPaidBy().getName();
            case 3 -> formattedDateTime;
            default -> null;
        };
    }
}
