package gui;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GroupTable extends AbstractTableModel{
    private final List<Map.Entry<Integer, String>> groupEntries;
    private final String[] columns = {"Group No.", "Group Name"};

    GroupTable(Map<Integer, String> groups){
        this.groupEntries = new ArrayList<>(groups.entrySet());
    }

    @Override
    public int getRowCount(){
        return groupEntries.size();
    }

    @Override
    public int getColumnCount(){
        return columns.length;
    }

    @Override
    public String getColumnName(int column){
        return columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        Map.Entry<Integer, String> entry = groupEntries.get(rowIndex);
        return switch (columnIndex){
            case 0 -> rowIndex + 1;
            case 1 -> entry.getValue();
            default -> null;
        };
    }

    public void removeRow(int rowIndex){
        groupEntries.remove(rowIndex);
    }
    public int getGroupId(int rowIndex){
        return groupEntries.get(rowIndex).getKey();
    }
}
