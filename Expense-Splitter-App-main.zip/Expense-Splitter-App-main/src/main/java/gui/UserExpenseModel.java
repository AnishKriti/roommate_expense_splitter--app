package gui;

import core.Expense;

import javax.swing.table.AbstractTableModel;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class UserExpenseModel extends AbstractTableModel {
    private final List<Expense> expenses;
    private final String[] columns = {"Description","Transaction", "Amount", "Date & Time"};
    UserExpenseModel(List<Expense> expenses){
        this.expenses = expenses;
    }
    @Override
    public int getRowCount(){
        return expenses.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int column){
        return columns[column];
    }

    private String getDateTime(int rowIndex){
        DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String formattedDateTime = "";
        if(expenses.get(rowIndex).getDateTime()!=null){
            formattedDateTime = dateTimeFormat.format(expenses.get(rowIndex).getDateTime());
        }
        return formattedDateTime;
    }
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        String formattedDateTime = getDateTime(rowIndex);
        Expense expense = expenses.get(rowIndex);
        return switch (columnIndex){
            case 0 -> expense.getDescription();
            case 1 -> expense.getTransactionType();
            case 2 -> expense.getAmount();
            case 3 -> formattedDateTime;
            default ->null;
        };
    }
}
