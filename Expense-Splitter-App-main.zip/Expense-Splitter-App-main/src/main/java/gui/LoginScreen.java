package gui;

import Security.Validate;
import core.User;
import db.ExpenseDAO;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

public class LoginScreen {
    private JFrame frame = new JFrame();
    private JPanel loginPanel;
    private JPanel registerPanel;
    private ExpenseDAO dao;

    public LoginScreen(ExpenseDAO doa){
        this.dao = doa;
        frame.setSize(420, 420);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(Color.LIGHT_GRAY);

        //Header Bar
        JPanel header = new JPanel();
        header.setBounds(0, 0, 420, 40);
        header.setLayout(new FlowLayout(FlowLayout.RIGHT));
        header.setBackground(Color.DARK_GRAY);
        JButton loginBtn = new JButton("Login");
        loginBtn.setFocusable(false);
        JButton registerBtn = new JButton("Register");
        registerBtn.setFocusable(false);
        header.add(loginBtn);
        header.add(registerBtn);

        loginWindow();
        registerWindow();

        //Button Action
        loginBtn.addActionListener(e -> {
            loginPanel.setVisible(true);
            registerPanel.setVisible(false);
        });
        registerBtn.addActionListener(e -> {
            loginPanel.setVisible(false);
            registerPanel.setVisible(true);
        });
        frame.add(loginPanel);
        frame.add(registerPanel);
        frame.add(header);
        frame.setVisible(true);
    }
    public void loginWindow(){
        //Login Panel
        loginPanel = new JPanel();
        loginPanel.setBounds(95, 60, 220, 250);
        loginPanel.setLayout(null);
        loginPanel.setBackground(Color.WHITE);
        loginPanel.setOpaque(true);

        //Border
        Border border = BorderFactory.createLineBorder(Color.GRAY, 3);
        loginPanel.setBorder(border);

        //Login Elements
        JLabel title = new JLabel("Login");
        JLabel usernameLabel = new JLabel("Username");
        JTextField usernameField = new JTextField();
        JLabel passLabel = new JLabel("Password");
        JPasswordField passwordField = new JPasswordField();
        JButton signInBtn = new JButton("Sign in");

        usernameField.addActionListener(e -> passwordField.requestFocus());
        passwordField.addActionListener(e -> signInBtn.doClick());

        //Bounds
        title.setBounds(65, 10, 160, 50);
        title.setFont(new Font("MV Boli", Font.BOLD, 35));
        usernameLabel.setBounds(30, 60, 160, 20);
        usernameField.setBounds(30, 80, 160, 35);
        passLabel.setBounds(30, 120, 160, 20);
        passwordField.setBounds(30, 140, 160, 35);
        signInBtn.setBounds(60, 190, 100, 30);

        //Panel additions
        loginPanel.add(title);
        loginPanel.add(usernameLabel);
        loginPanel.add(usernameField);
        loginPanel.add(passLabel);
        loginPanel.add(passwordField);
        loginPanel.add(signInBtn);
        loginPanel.setVisible(true);

        signInBtn.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            Validate validate = new Validate(username, password, dao);
            if(validate.validateUsername() && validate.validatePassword()){
                mainWindow(validate.getValidatedUser());
            }
            else if(!validate.validateUsername()){
                JOptionPane.showMessageDialog(frame, "User not found. Kindly Register.");
            }
            else if(!validate.validatePassword()){
                JOptionPane.showMessageDialog(frame, "Incorrect password");
            }
        });
    }
    public void registerWindow(){
        registerPanel = new JPanel();
        registerPanel.setBounds(95, 60, 220, 300);
        registerPanel.setLayout(null);
        registerPanel.setBackground(Color.WHITE);
        registerPanel.setOpaque(true);

        //Border
        Border border = BorderFactory.createLineBorder(Color.GRAY, 3);
        registerPanel.setBorder(border);

        //Login Elements
        JLabel title = new JLabel("Register");
        JLabel usernameLabel = new JLabel("Username");
        JTextField usernameField = new JTextField();
        JLabel emailLabel = new JLabel("Email");
        JTextField emailField = new JTextField();
        JLabel passLabel = new JLabel("Password");
        JTextField passwordField = new JTextField();
        JButton registerBtn = new JButton("Register");

        //Bounds
        title.setBounds(35, 10, 160, 50);
        title.setFont(new Font("MV Boli", Font.BOLD, 35));
        usernameLabel.setBounds(30, 60, 160, 20);
        usernameField.setBounds(30, 80, 160, 35);
        emailLabel.setBounds(30, 120, 160, 20);
        emailField.setBounds(30, 140, 160, 35);;
        passLabel.setBounds(30, 180, 160, 20);
        passwordField.setBounds(30, 200, 160, 35);
        registerBtn.setBounds(60, 240, 100, 30);

        registerBtn.addActionListener(e -> addUser(usernameField.getText(), emailField.getText(), passwordField.getText()));

        //Panel additions
        registerPanel.add(title);
        registerPanel.add(usernameLabel);
        registerPanel.add(usernameField);
        registerPanel.add(emailLabel);
        registerPanel.add(emailField);
        registerPanel.add(passLabel);
        registerPanel.add(passwordField);
        registerPanel.add(registerBtn);
        registerPanel.setVisible(false);
    }
    public void addUser(String username, String email, String password) {
        User user = new User(0, username, email, password);
        if (dao.saveUser(user)) {
            JOptionPane.showMessageDialog(frame, "Registered Successfully");
            registerPanel.setVisible(false);
            loginPanel.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(
                    frame,
                    "Registration failed. Username or email may already exist."
            );
        }
    }
    public void mainWindow(User currentUser){
        frame.dispose();
        MainWindow mainWindow = new MainWindow(dao, currentUser);
        mainWindow.show();
    }
}
