package gui;

import engine.Transaction;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class DebtSimplifierTable extends AbstractTableModel{
    private List<Transaction> transactions;
    private String[] columns = {"From", "To", "Amount"};

    DebtSimplifierTable(List<Transaction> transactions){
        this.transactions = transactions;
    }

    @Override
    public int getRowCount(){
        return transactions.size();
    }

    @Override
    public int getColumnCount(){
        return columns.length;
    }

    @Override
    public String getColumnName(int column){
        return columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        Transaction transaction = transactions.get(rowIndex);
        return switch(columnIndex){
            case 0 -> transaction.getFrom().getName();
            case 1 -> transaction.getTo().getName();
            case 2 -> String.format("%.2f", transaction.getAmount());
            default -> null;
        };
    }
}
