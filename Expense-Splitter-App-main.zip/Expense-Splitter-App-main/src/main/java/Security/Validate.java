package Security;

import core.User;
import db.ExpenseDAO;

import java.util.List;

public class Validate {
    String username;
    String password;
    ExpenseDAO dao;

    public Validate(String username, String password, ExpenseDAO dao){
        this.username = username;
        this.password = password;
        this.dao = dao;
    }
    private List<User> getUsers(){
        return dao.getAllUsers();
    }
    public boolean validateUsername(){
        boolean validation = false;
        for(User user : getUsers()){
            if(username.equals(user.getName())){
                validation = true;
                break;
            }
        }
        return validation;
    }
    public boolean validatePassword(){
        boolean validation = false;
        for(User user : getUsers()){
            if(username.equals(user.getName()) && password.equals(user.getPassword())){
                validation = true;
                break;
            }
        }
        return validation;
    }
    public User getValidatedUser(){
        for(User user : getUsers()){
            if(username.equals(user.getName()) && password.equals(user.getPassword())){
                return user;
            }
        }
        return null;
    }
}
