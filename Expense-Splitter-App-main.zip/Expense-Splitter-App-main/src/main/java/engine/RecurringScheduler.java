package engine;

import core.RecurringExpense;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class RecurringScheduler{
    public void schedule(RecurringExpense expense){
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(expense, 0, expense.getIntervalDays(), TimeUnit.DAYS);
    }
}
