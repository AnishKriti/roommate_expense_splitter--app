package engine;

import core.User;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DebtSimplifier {
    public List<Transaction> simplify(Map<User, Double> balances){
        List<User> creditors = new ArrayList<>();
        List<User> debtors = new ArrayList<>();
        List<Transaction> result = new ArrayList<>();

        for(Map.Entry<User, Double> entry : balances.entrySet()){ //entrySet is faster than using keySet as we dont have to invoke getKey everytime
            if (entry.getValue()>0) {
                creditors.add(entry.getKey());
            }
            else if(entry.getValue()<0){
                debtors.add(entry.getKey());
            }
        }

        while(!creditors.isEmpty() && !debtors.isEmpty()){
            User debtor = debtors.get(0);
            User creditor = creditors.get(0);

            double debtAmount = Math.abs(balances.get(debtor));
            double creditAmount = balances.get(creditor);

            double settledAmount = Math.min(debtAmount, creditAmount);

            result.add(new Transaction(debtor, creditor, settledAmount));

            balances.put(debtor, -(debtAmount-settledAmount));
            balances.put(creditor, creditAmount - settledAmount);

            if(settledAmount == debtAmount) {
                debtors.remove(0);
            }
            if(settledAmount == creditAmount){
                creditors.remove(0);
            }

        }
        return result;
    }
}
