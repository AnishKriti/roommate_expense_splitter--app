package engine;

import core.User;
import java.util.Map;

public class FairnessEngine {
    public double calculateScore(Map<User, Double> payments){
        double total = 0;
        double distSum = 0;
        for(Map.Entry<User, Double> entry : payments.entrySet()){
            total += entry.getValue();
        }
        double avgPayment = total/payments.size();
        for(Map.Entry<User, Double> entry : payments.entrySet()){
            double dist = Math.abs(entry.getValue() - avgPayment);
            distSum += dist;
        }
        double score = distSum/payments.size();
        return score;
    }
}
