package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {
    private Connection con;
    public Connection getConnection(){
        return con;
    }
    public void connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection setupCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "1234");
            Statement setupStmt = setupCon.createStatement();
            setupStmt.execute("CREATE DATABASE IF NOT EXISTS expensemanager");
            setupStmt.close();
            setupCon.close();
 
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/expensemanager", "root", "1234");
        }
        catch(SQLException e){
            System.out.println("DB Error: " + e.getMessage());
        }
        catch(ClassNotFoundException e){
            System.out.println("Driver not found: " + e.getMessage());
        }
    }
    public void createTable(){
        try {
            Statement stmt = con.createStatement();
            stmt.execute("""
                    CREATE TABLE IF NOT EXISTS users(
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        name VARCHAR(50),
                        email VARCHAR(100) UNIQUE,
                        password VARCHAR(200) NOT NULL)
                    """);
            stmt.execute("""
                    CREATE TABLE IF NOT EXISTS expenses(
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    description VARCHAR(100),
                    transaction VARCHAR(10),
                    amount DOUBLE,
                    paid_by VARCHAR(50),
                    paid_by_id INT,
                    date_time DATETIME,
                    FOREIGN KEY (paid_by_id) REFERENCES users(id)
                    )
                    """);
            stmt.execute("""
                    CREATE TABLE IF NOT EXISTS trip_group(
                        group_id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        group_name VARCHAR(50),
                        user_id INT,
                        FOREIGN KEY (user_id) REFERENCES users(id)
                    )
                    """);
            stmt.execute("""
                    CREATE TABLE IF NOT EXISTS group_members(
                    id INTEGER PRIMARY KEY AUTO_INCREMENT,
                    group_id INTEGER,
                    name VARCHAR(50),
                    email VARCHAR(50),
                    total_paid DOUBLE,
                    total_owed DOUBLE,
                    FOREIGN KEY (group_id) REFERENCES trip_group(group_id)
                    )
                    """);
            stmt.execute("""
                    CREATE TABLE IF NOT EXISTS group_expenses(
                        id INTEGER PRIMARY KEY AUTO_INCREMENT,
                        group_id INTEGER,
                        description VARCHAR(150),
                        amount DOUBLE,
                        paid_by_id INTEGER,
                        paid_by VARCHAR(50),
                        date_time DATETIME,
                        FOREIGN KEY (paid_by_id) REFERENCES group_members(id)
                    )
                    """);
        } 
        catch (SQLException e) {
            System.out.println("DB Error: " + e.getMessage());
        }
    }
}
