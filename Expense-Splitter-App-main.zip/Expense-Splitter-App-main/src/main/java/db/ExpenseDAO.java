package db;

import core.Expense;
import core.Group;
import core.OneTimeExpense;
import core.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpenseDAO {
    private final DatabaseManager db;
    
    public ExpenseDAO(DatabaseManager db){
        this.db = db;
    }

    //Login Users
    public boolean saveUser(User user){
        try {
            PreparedStatement ps = db.getConnection().prepareStatement("INSERT INTO users(name, email, password) VALUES (?, ?, ?)");
            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            return ps.executeUpdate() == 1;
        } 
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
            return false;
        }
    }
    public void saveExpense(Expense expense){
        try (PreparedStatement ps = db.getConnection().prepareStatement("INSERT INTO expenses(description, transaction, amount, paid_by, paid_by_id, date_time) VALUES (?, ?, ?, ?, ?, ?)");){
            ps.setString(1, expense.getDescription());
            ps.setString(2, expense.getTransactionType());
            ps.setDouble(3, expense.getAmount());
            ps.setString(4, expense.getPaidBy().getName());
            ps.setInt(5, expense.getPaidBy().getId());
            ps.setObject(6, expense.getDateTime());
            ps.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
        }
        
    }
    public List<Expense> getUserExpense(int currentUser){
        List<Expense> expenses = new ArrayList<>();
        try(PreparedStatement ps = db.getConnection().prepareStatement("SELECT * FROM expenses WHERE paid_by_id=?")){
            ps.setInt(1, currentUser);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
//                String paidBy = rs.getString("paid_by");
                OneTimeExpense e = new OneTimeExpense(
                        rs.getInt("id"),
                        rs.getString("description"),
                        rs.getDouble("amount"),
                        new User(rs.getInt("paid_by_id"), rs.getString("paid_by")),
                        rs.getObject("date_time", LocalDateTime.class),
                        rs.getString("transaction")
                );
                expenses.add(e);
            }
            return expenses;
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
            return expenses;
        }
    }
    public void deleteExpense(int id){
        try(PreparedStatement ps = db.getConnection().prepareStatement("DELETE FROM expenses WHERE id=?")){
            ps.setInt(1, id);
            ps.executeUpdate();
        }
        catch (SQLException e){
            System.out.println("DB Error: "+e.getMessage());
        }
    }
    public double getSumAmount(int userId, String transactionType){
        double totalSpendAmount = 0;
        try(PreparedStatement ps = db.getConnection().prepareStatement("SELECT SUM(amount) AS total FROM expenses WHERE transaction=? AND paid_by_id=?")){
            ps.setString(1, transactionType);
            ps.setInt(2, userId);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                totalSpendAmount = rs.getDouble("total");
            }
            return totalSpendAmount;
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
            return totalSpendAmount;
        }
    }
    public double getSumAmount(int userId, String transactionType, LocalDate startDate, LocalDate endDate){
        double totalSpendAmount = 0;
        try(PreparedStatement ps = db.getConnection().prepareStatement("SELECT SUM(amount) AS total FROM expenses WHERE transaction=? AND paid_by_id=? AND date_time BETWEEN ? AND ?;")){
            ps.setString(1, transactionType);
            ps.setInt(2, userId);
            ps.setObject(3, startDate);
            ps.setObject(4, endDate);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                totalSpendAmount = rs.getDouble("total");
            }
            return totalSpendAmount;
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
            return totalSpendAmount;
        }
    }


    // To validate users
    public List<User> getAllUsers(){
        List<User> users = new ArrayList<>();
        try {
            Statement stmt = db.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM users");
            while(rs.next()){
                User u = new User(rs.getInt("id"), rs.getString("name"),rs.getString("email"), rs.getString("password"));
                //u.addPayment(rs.getDouble("total_paid"));
                //u.addDebt(rs.getDouble("total_owed"));
                users.add(u);
            }
            return users;

        } 
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
            return users;
        }
    }

    //Groups
    public int saveGroup(Group group){
        try(PreparedStatement ps = db.getConnection().prepareStatement("INSERT INTO trip_group(group_name) VALUES (?)", Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1, group.getName());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if(keys.next()){
                return keys.getInt(1);
            }
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
        }
        return -1;
    }
    public Map<Integer, String> getAllGroups(){
        Map<Integer,String> groups = new HashMap<>();
        try{
            Statement stmt = db.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM trip_group");
            while(rs.next()){
                groups.put(rs.getInt("group_id"),rs.getString("group_name"));
            }
            return groups;
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
            return groups;
        }
    }
    public void deleteGroup(int groupId){
        try(PreparedStatement ps = db.getConnection().prepareStatement("DELETE FROM trip_group WHERE group_id=?");
        PreparedStatement ps1 = db.getConnection().prepareStatement("DELETE FROM group_members WHERE group_id=?");
        PreparedStatement ps2 = db.getConnection().prepareStatement("DELETE FROM group_expenses WHERE group_id=?")){
            ps.setInt(1, groupId);
            ps1.setInt(1, groupId);
            ps2.setInt(1, groupId);
            ps2.executeUpdate();
            ps1.executeUpdate();
            ps.executeUpdate();
        }
        catch (SQLException e){
            System.out.println("DB Error: "+e.getMessage());
        }
    }

    public void saveGroupMembers(int groupId, User user){
        try(PreparedStatement ps = db.getConnection().prepareStatement(
                "INSERT INTO group_members(group_id, name, email) VALUES (?, ?, ?)")){
            ps.setInt(1, groupId);
            ps.setString(2, user.getName());
            ps.setString(3, user.getEmail());
            ps.executeUpdate();
        }catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
        }
    }
    public List<User> getAllMembers(int groupID){
        List<User> members = new ArrayList<>();
        try(PreparedStatement ps = db.getConnection().prepareStatement("SELECT * FROM group_members WHERE group_id=?")){
            ps.setInt(1, groupID);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                User u = new User(rs.getInt("id"), rs.getString("name"), rs.getString("email"));
                u.setTotalPaid(rs.getDouble("total_paid"));
                u.setTotalOwed(rs.getDouble("total_owed"));
                members.add(u);
            }
            return members;
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
            return members;
        }
    }
    public void deleteGroupMembers(int id){
        try(PreparedStatement ps = db.getConnection().prepareStatement("DELETE FROM group_members WHERE id=?");
            PreparedStatement ps1 = db.getConnection().prepareStatement("DELETE FROM group_expenses WHERE paid_by_id=?")){
            ps.setInt(1, id);
            ps1.setInt(1, id);
            ps1.executeUpdate();
            ps.executeUpdate();
        }
        catch (SQLException e){
            System.out.println("DB Error: "+e.getMessage());
        }
    }


    public void saveMemberAmount(User user){
        try(PreparedStatement ps = db.getConnection().prepareStatement("UPDATE group_members SET total_paid=?, total_owed=? WHERE id=?")){

            // group_members table
            ps.setInt(3, user.getId());
            ps.setDouble(1, user.getTotalPaid());
            ps.setDouble(2, user.getTotalOwed());
            ps.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
        }
    }
    public void saveMemberExpense(Expense expense, int groupID){
        try(PreparedStatement ps1 = db.getConnection().prepareStatement("INSERT INTO group_expenses(group_id, description, amount,paid_by_id, paid_by, date_time) VALUES (?, ?, ?, ?, ?, ?)")){
            // group_expenses
            ps1.setInt(1, groupID);
            ps1.setString(2, expense.getDescription());
            ps1.setDouble(3, expense.getAmount());
            ps1.setInt(4, expense.getPaidBy().getId());
            ps1.setString(5, expense.getPaidBy().getName());
            ps1.setObject(6, expense.getDateTime());
            ps1.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("DB Error: "+e.getMessage());
        }
    }
    public List<Expense> getMemberExpense(int groupID){
        List<Expense> expenses = new ArrayList<>();
        try(PreparedStatement ps = db.getConnection().prepareStatement("SELECT * FROM group_expenses WHERE group_id=?")){
            ps.setInt(1, groupID);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                String paidBy = rs.getString("paid_by");
                int id = rs.getInt("paid_by_id");
                OneTimeExpense e = new OneTimeExpense(
                        rs.getInt("id"),
                        rs.getString("description"),
                        rs.getDouble("amount"),
                        new User(id, paidBy), // Creates a temporary user object to fetch the name of the paidBy user
                        rs.getObject("date_time", LocalDateTime.class),
                        "Debit"
                );
                expenses.add(e);
            }
            return expenses;
        }
        catch (SQLException e){
            System.out.println("DB Error: "+e.getMessage());
            return expenses;
        }
    }
    public void deleteMemberExpense(int id){
        try(PreparedStatement ps = db.getConnection().prepareStatement("DELETE FROM group_expenses WHERE id=?")){
            ps.setInt(1, id);
            ps.executeUpdate();
        }
        catch (SQLException e){
            System.out.println("DB Error: "+e.getMessage());
        }
    }

    //Monthly Report
    public List<Expense> getMonthlyExpense(int currentUser_id, LocalDate startDate, LocalDate endDate){
        List<Expense> expenses = new ArrayList<>();
        try(PreparedStatement ps = db.getConnection().prepareStatement("SELECT * FROM expenses WHERE date_time BETWEEN (?) AND (?) AND paid_by_id = (?)")){
            ps.setObject(1, startDate);
            ps.setObject(2, endDate);
            ps.setInt(3, currentUser_id);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                OneTimeExpense e = new OneTimeExpense(
                        rs.getInt("id"),
                        rs.getString("description"),
                        rs.getDouble("amount"),
                        new User(rs.getInt("paid_by_id"), rs.getString("paid_by")),
                        rs.getObject("date_time", LocalDateTime.class),
                        rs.getString("transaction")
                );
                expenses.add(e);
            }
            return expenses;
        }catch(SQLException e){
            System.out.println("DB Error: "+e.getMessage());
            return expenses;
        }
    }
}
