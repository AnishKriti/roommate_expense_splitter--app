package report;

import core.User;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReportExporter {
    public void export(JTable monthlyReportTable, User currentUser){
        try(FileOutputStream outputStream = new FileOutputStream(".MonthlyReport-"+currentUser.getName()+".xlsx")){
        TableModel tableModel = monthlyReportTable.getModel();
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Monthly Report");

        //Header Row
        XSSFRow headerRow = sheet.createRow(0);
        for(int i=0; i< tableModel.getColumnCount(); i++){
            XSSFCell headerCell = headerRow.createCell(i);
            headerCell.setCellValue(tableModel.getColumnName(i));

            CellStyle style = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            style.setFont(font);
            headerCell.setCellStyle(style);
        }

        //Data
        for(int i=0; i<tableModel.getRowCount(); i++){
            XSSFRow row = sheet.createRow(i+1);
            for(int j=0; j<tableModel.getColumnCount(); j++){
                XSSFCell cell = row.createCell(j);
                Object value = tableModel.getValueAt(i, j);
                if(value!=null){
                    if(value instanceof Double){
                        cell.setCellValue((Double) value);
                    }
                    else{
                        cell.setCellValue(value.toString());
                    }
                }
            }
        }

        //Auto Size
        for(int i=0; i<tableModel.getColumnCount(); i++){
            sheet.autoSizeColumn(i);
        }

        //writing the Excel file
        workbook.write(outputStream);
            JOptionPane.showMessageDialog(null, "Report Exported Successfully!");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
