package core;

public class User {
    private int id;
    private String name;
    private String email;
    private String password;
    private double totalOwed;
    private double totalPaid;
    private String description;

    // Constructors
    public User(int id, String name){
        // this.id = id;
        // this.name = name;
        this(id, name, "NA");
    }
    //For existing users
    public User(int id, String name, String email){
        this.id = id;
        this.name = name;
        this.email = email;
    }
    // For new users
    public User(int id, String name, String email, String password){
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    //Getters
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public String getEmail(){
        return email;
    }
    public String getPassword(){return password;}
    public double getTotalOwed(){
        return totalOwed;
    }
    public double getTotalPaid(){
        return totalPaid;
    }
    public String getDescription(){
        return description;
    }

    public void setDescription(String description){
        this.description = description;
    }
    public void setTotalOwed(double totalOwed){this.totalOwed = totalOwed;}
    public void setTotalPaid(double totalPaid){this.totalPaid = totalPaid;}

    public void addPayment(double amount){
        totalPaid += amount;
    }
    public void addDebt(double amountPerPerson){
        totalOwed += amountPerPerson;
    }
}
