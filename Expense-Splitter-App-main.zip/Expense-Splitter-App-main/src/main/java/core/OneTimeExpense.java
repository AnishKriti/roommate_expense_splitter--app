package core;

import java.time.LocalDateTime;

public class OneTimeExpense extends Expense{
    public OneTimeExpense(int id, String description, double amount, User paidBy, LocalDateTime dateTime, String transactionType){
        super(id, description, amount, paidBy, dateTime, transactionType);
    }
    @Override
    public void apply(){
        System.out.println("Expense Recorded: "+getDescription());
    }
}
