package core;

import java.time.LocalDateTime;

public class RecurringExpense extends Expense implements Runnable{
    private int intervalDays;
    public RecurringExpense(int id, String description, double amount, User paidBy, int intervalDays, LocalDateTime datetime){
        super(id, description, amount, paidBy, datetime, "debit");
        this.intervalDays = intervalDays;
    }
    public int getIntervalDays(){
        return intervalDays;
    }
    @Override
    public void apply(){
        System.out.println("Recurring expense scheduled every " + intervalDays + " days: "+getDescription());
    }
    @Override
    public void run(){
        apply();
    }
}
