package core;

import java.time.LocalDateTime;

public abstract class Expense {
    private int id;
    private String description;
    private double amount;
    private User paidBy;
    private LocalDateTime dateTime;
    private String transactionType;

    public Expense(int id, String description, double amount, User paidBy, LocalDateTime dateTime, String transactionType){
        this.id = id;
        this.description = description;
        this.amount = amount;
        this.paidBy = paidBy;
        this.dateTime = dateTime;
        this.transactionType = transactionType;
    }

    public int getId(){
        return id;
    }
    public String getDescription(){
        return description;
    }
    public double getAmount(){
        return amount;
    }
    public User getPaidBy(){
        return paidBy;
    }
    public LocalDateTime getDateTime(){
        return dateTime;
    }
    public String getTransactionType(){
        return transactionType;
    }

    public abstract void apply();
}
