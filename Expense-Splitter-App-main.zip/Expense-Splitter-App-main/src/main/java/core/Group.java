package core;

import java.util.ArrayList;

public class Group {
    private String name;
    private ArrayList<User> members = new ArrayList<>();
    private ArrayList<Expense> expenses = new ArrayList<>();

    public Group(String name) {
        this.name = name;
    }
//    public void addMember(User u){
//        members.add(u);
//    }
//    public void addExpense(Expense e){
//        expenses.add(e);
//    }

    public String getName(){ return name; }
//    public ArrayList<User> getMembers(){
//        return members;
//    }
//    public ArrayList<Expense> getExpenses(){
//        return expenses;
//    }
}
