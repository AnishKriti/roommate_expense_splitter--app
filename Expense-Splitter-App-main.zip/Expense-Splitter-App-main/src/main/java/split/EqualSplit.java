package split;
import core.User;

import java.util.List;

public class EqualSplit{
    public double split(double amount, List<User> members){
        return amount / members.size();
    }
}
