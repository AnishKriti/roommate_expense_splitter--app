# 💰 Expense Splitter & Management System

A robust, full-featured Java desktop application designed for tracking personal finances and seamlessly splitting group expenses with automated debt simplification algorithms, relational database persistence, and Excel report generation.

---

## 🌟 Key Features

### 🔐 1. Authentication & User Management
* **User Registration & Login**: Secure account creation and authentication system with input validation and duplicate prevention.
* **Session Management**: Dynamic user context maintaining active user profiles and personalized data throughout the session.

### 📊 2. Personal Finance Dashboard
* **Real-time Overview**: Live metrics displaying **Total Money Spent (Debits)** and **Total Money Received (Credits)** in Indian Rupees (`₹`).
* **Expense Logging**: Add personal transactions with custom descriptions, amount, transaction type (Debit/Credit), and automatic timestamps.
* **Interactive Expense Table**: Browse and review historical transactions with detailed records.

### 👥 3. Group Expenses & Smart Splitting
* **Group Management**: Create custom groups (trips, housemates, projects, events) and add multiple members.
* **Shared Expense Tracking**: Log group expenses with specific payers, calculating individual member shares.
* **Automated Member Balances**: Tracks cumulative `Total Paid`, `Total Owed`, and real-time net balances for each group participant.

### 🧠 4. Algorithmic Debt Simplification & Fairness
* **Smart Debt Simplification (`DebtSimplifier`)**: Implements a greedy matching algorithm that settles multi-person debts in the minimal number of direct transactions (eliminating circular repayments).
* **Fairness Metric Engine (`FairnessEngine`)**: Computes statistical variance from average spending to evaluate payment equality among members.
* **Recurring Expense Structure**: Extensible OOP models for one-time and recurring expense scheduling.

### 📑 5. Reporting & Excel Export
* **Date-Range Filtering**: Filter monthly expenses by specifying custom start and end date ranges.
* **Automated Excel Export**: Generates styled `.xlsx` workbooks using **Apache POI**, featuring bold headers, structured data formatting, and auto-adjusted column widths.

---

## 🏗️ Architecture & OOP Design

The application follows a modular, layered architecture adhering to core **Object-Oriented Programming (OOP)** principles:

```
src/main/java/
├── Main.java                 # Application entry point
├── core/                     # Domain models (OOP Abstractions & Inheritance)
│   ├── User.java             # User entity and balance tracking
│   ├── Expense.java          # Abstract base class for expense types
│   ├── OneTimeExpense.java   # Concrete implementation of one-time expense
│   ├── RecurringExpense.java # Concrete implementation for recurring expense
│   └── Group.java            # Group domain model
├── db/                       # Persistence layer (DAO Pattern)
│   ├── DatabaseManager.java  # Connection management & auto-schema migration
│   └── ExpenseDAO.java        # Prepared statements & relational CRUD queries
├── engine/                   # Business logic & algorithms
│   ├── DebtSimplifier.java   # Greedy debt minimization algorithm
│   ├── FairnessEngine.java   # Group spending variance & fairness calculator
│   ├── RecurringScheduler.java# Scheduled expense handlers
│   └── Transaction.java      # Transaction value object (debtor -> creditor -> amount)
├── gui/                      # Java Swing UI layer
│   ├── LoginScreen.java      # Sign in & Registration UI dialogs
│   ├── MainWindow.java       # Main dashboard, tabbed views, & modal windows
│   ├── GroupTable.java       # Custom table models for groups
│   ├── MemberExpenseTable.java
│   ├── MemberTableModel.java
│   ├── DebtSimplifierTable.java
│   ├── TableCells.java
│   └── UserExpenseModel.java
├── report/                   # Data export utilities
│   └── ReportExporter.java   # Apache POI Excel (.xlsx) generator
├── Security/                 # Authentication validators
│   └── Validate.java         # User credential & registration verification
└── split/                    # Splitting strategies
    └── EqualSplit.java       # Equal expense distribution strategy
```

### 🧩 OOP Principles Demonstrated
* **Abstraction**: Abstract `Expense` base class defining core properties and contract methods like `apply()`.
* **Inheritance & Polymorphism**: `OneTimeExpense` and `RecurringExpense` extending `Expense`.
* **Encapsulation**: Model attributes kept private with structured getters, setters, and mutation helpers.
* **Separation of Concerns / DAO Pattern**: Clean decoupling between Swing GUI, algorithmic engines, and JDBC database access.

---

## 🗄️ Database Schema

The application uses **MySQL**. Tables and relations are **automatically created** upon launching the application:

```mermaid
erDiagram
    USERS ||--o{ EXPENSES : "pays"
    USERS ||--o{ TRIP_GROUP : "creates"
    TRIP_GROUP ||--|{ GROUP_MEMBERS : "contains"
    GROUP_MEMBERS ||--o{ GROUP_EXPENSES : "pays"

    USERS {
        int id PK
        varchar name
        varchar email UK
        varchar password
    }
    EXPENSES {
        int id PK
        varchar description
        varchar transaction
        double amount
        varchar paid_by
        int paid_by_id FK
        datetime date_time
    }
    TRIP_GROUP {
        int group_id PK
        varchar group_name
        int user_id FK
    }
    GROUP_MEMBERS {
        int id PK
        int group_id FK
        varchar name
        varchar email
        double total_paid
        double total_owed
    }
    GROUP_EXPENSES {
        int id PK
        int group_id FK
        varchar description
        double amount
        int paid_by_id FK
        varchar paid_by
        datetime date_time
    }
```

---

## 🛠️ Tech Stack & Dependencies

* **Language**: Java 17
* **GUI Toolkit**: Java Swing & AWT
* **Database**: MySQL 8.x / 9.x via MySQL Connector/J `9.0.0`
* **Excel Processing**: Apache POI & Apache POI OOXML `5.2.5`
* **Utilities**: Apache Commons (`codec`, `collections4`, `compress`, `io`)
* **Logging**: Apache Log4j 2 (`log4j-core`, `log4j-api` `2.21.1`)
* **Build System**: Maven / Maven Wrapper

---

## ⚙️ Prerequisites & Setup

### 1. Requirements
* **JDK 17** or higher installed and configured in `JAVA_HOME`.
* **MySQL Server** running locally on port `3306`.

### 2. Database Setup
1. Start your local MySQL service.
2. The database initialization is handled automatically by `DatabaseManager.java`.
   * *Note*: By default, `DatabaseManager.java` connects to `localhost:3306` with user `root` and password `1234` (or your configured credentials). If your MySQL password differs, update the credentials in `src/main/java/db/DatabaseManager.java`.

---

## 🚀 Running the Application

### Option A: Using the Maven Wrapper (Windows - Quick Launch)
Simply double-click `run.bat` or execute in PowerShell / Command Prompt:
```cmd
run.bat
```
*The script automatically detects `mvnw.cmd`, downloads dependencies, compiles the project, and launches the app.*

### Option B: Using Maven CLI
```bash
mvn compile exec:java
```

### Option C: Using an IDE (IntelliJ IDEA / Eclipse / VS Code)
1. Open or import the folder as a **Maven Project**.
2. Wait for dependencies to resolve.
3. Locate `src/main/java/Main.java`.
4. Right-click and select **Run 'Main'**.

---

## 📖 Usage Guide

1. **Register / Login**: Launch the app and register a new user account, then log in.
2. **Personal Expenses**:
   - Click **Add Expense** to record debits (spent) or credits (income/reimbursement).
   - Click **View Expenses** to view all recorded transactions.
3. **Manage Groups & Split Costs**:
   - Navigate to **Groups** -> **Add Group**.
   - Open your group to add members.
   - Click **Add Amount / Expense** to log shared purchases and select who paid.
   - Click **Simplify Debts** to see the optimized settlement transactions calculated by the engine.
4. **Export Reports**:
   - Click **Monthly Report**, choose your date range, and click **Export** to save an `.xlsx` file to your project directory.